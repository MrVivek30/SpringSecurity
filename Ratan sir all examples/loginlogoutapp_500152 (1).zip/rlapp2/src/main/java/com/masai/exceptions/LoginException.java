package com.masai.exceptions;

public class LoginException extends Exception{

	public LoginException() {
		// TODO Auto-generated constructor stub
	}
	
	public LoginException(String message) {
		super(message);
	}
	
	
}
