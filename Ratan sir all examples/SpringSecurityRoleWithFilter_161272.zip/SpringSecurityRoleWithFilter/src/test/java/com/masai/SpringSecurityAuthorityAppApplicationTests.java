package com.masai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityAuthorityAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
